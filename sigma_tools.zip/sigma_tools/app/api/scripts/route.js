import fs from "fs";
import path from "path";
import { NextResponse } from "next/server";

const filePath = path.join(process.cwd(), "data/scripts.json");

export async function GET() {
  const data = JSON.parse(fs.readFileSync(filePath));
  return NextResponse.json(data);
}

export async function POST(req) {
  const body = await req.json();
  const data = JSON.parse(fs.readFileSync(filePath));

  data.push(body);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));

  return NextResponse.json({ success: true });
}