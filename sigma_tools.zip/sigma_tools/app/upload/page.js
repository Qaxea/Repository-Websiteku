"use client";
import { useState } from "react";

export default function Upload() {
  const [name, setName] = useState("");
  const [code, setCode] = useState("");

  async function uploadScript() {
    const res = await fetch("/api/scripts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, code })
    });

    if (res.ok) {
      alert("Script berhasil diupload");
      setName("");
      setCode("");
    } else {
      alert("Upload gagal");
    }
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>Upload Lua Script</h2>

      <input
        placeholder="Nama Script"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <br /><br />

      <textarea
        placeholder="Isi script Lua"
        rows={10}
        value={code}
        onChange={(e) => setCode(e.target.value)}
      />
      <br /><br />

      <button onClick={uploadScript}>Upload</button>
    </div>
  );
}